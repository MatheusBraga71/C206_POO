package AV3.exception;

public class PrejuizoException extends Throwable{

    public PrejuizoException(String mensagem){
        super(mensagem);
    }
}
