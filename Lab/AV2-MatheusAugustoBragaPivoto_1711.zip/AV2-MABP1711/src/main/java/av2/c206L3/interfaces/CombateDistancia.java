package av2.c206L3.interfaces;

public interface CombateDistancia {

    public void CastarSpell();
}
