package av2.c206L3.interfaces;

public interface Alianca {

    public void ForTheAlliance();

    public void InvadirHorda();
}
