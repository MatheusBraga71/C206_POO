package av2.c206L3.interfaces;

public interface CombateCorpoACorpo {

    public void SacarArma();
}