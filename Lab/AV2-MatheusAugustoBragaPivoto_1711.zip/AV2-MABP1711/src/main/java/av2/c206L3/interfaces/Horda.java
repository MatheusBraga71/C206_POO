package av2.c206L3.interfaces;

public interface Horda {

    public void ForTheHorde();

    public void InvadirAlianca();
}
