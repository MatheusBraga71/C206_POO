//MATHEUS AUGUSTO BRAGA PIVOTO 1711

public class Motor {

    float velocidadeMaxima;

    void mostraInfo(){
        System.out.print("Velocidade máxima: " + velocidadeMaxima + "\n");
        System.out.print("\n");
    }
}
